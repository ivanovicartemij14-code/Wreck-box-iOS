# Wreckbox iOS rebuild scaffold

This repository contains the extracted web UI from Wreckbox Android APK and a Capacitor-based iOS wrapper scaffold.

**This is not a prebuilt IPA.** GitHub Actions runs on a macOS runner and attempts to build an unsigned iOS app, then packages the `.app` as `Wreckbox-unsigned.ipa`.

## Build

1. Upload the repository contents to GitHub, preserving `.github/workflows/build-ios.yml`.
2. Open **Actions** and run **Build unsigned iOS IPA** (or push to `main`).
3. Download the `Wreckbox-unsigned-IPA` artifact from a successful run.
4. Sign it with a compatible signing tool/certificate before attempting installation.

## Limitations

- Only the web UI extracted from the Android APK is included; original Android native code is not ported.
- The workflow and app have not been tested on a real iPhone.
- An unsigned IPA is not directly installable. Build success is not guaranteed; inspect the workflow logs if it fails.
