import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.itslamba.wreckbox',
  appName: 'Wreckbox',
  webDir: 'www',
  backgroundColor: '#0c0e11',
  ios: {
    contentInset: 'automatic'
  }
};

export default config;
